# Virtual Machines

1. Installer VirtualBox depuis le [site officiel](https://www.virtualbox.org/wiki/Downloads)

2. Après installation, prendre également depuis la même page "VirtualBox 6.1.34 Oracle VM VirtualBox Extension Pack"
pour d'avantage de support.


3. Pour faire tourner des VM en x64, il est nécessaire de rebooter la machine utilisateur et d'accéder à son BIOS (mash F2, F12, Back selon le modèle...)
-Une fois dans le BIOS, il faut accéder aux Advanced Settings (paramètres avancés) et autoriser ('enable') une des options suivantes selon la machine 👍

```
    -Enable virtualization; the setting may be called 'VT-x', 'AMD-V', 'SVM', or 'Vanderpool'. 
    -Enable Intel VT-d or AMD IOMMU if the options are available.
```

On peut vérifier si la virtualisation est autorisé en faisant Ctrl-Shift-Esc et en se rendant sur l'onglet "Performances/Processeur". En bas à droite, on nous dit si la virtualisation est active ou non.

4. Télécharger les images disque (.iso) des OS Linux qui nous intéresse (Ubuntu, Mint, Kali etc).
[Ubuntu](https://ubuntu.com/)                           Plus facile d'accès que Debian. Design original
[Mint](https://www.linuxmint.com/)                      Dérivé d'Ubuntu avec un design plus sobre, proche de Windows
[Kubuntu](https://kubuntu.org/getkubuntu/)              Ubuntu, mais avec KDE Plasma à la place de Gnome
[Fedora](https://fedoraproject.org/)
[Nitrux](https://nxos.org/)
[Zorin](https://zorin.com/os/)
[Pop!_OS](https://pop.system76.com/)

Pour les pros de Linux
[Debian](https://www.debian.org/index.fr.html)
[Arch](https://archlinux.org/)

Pour les Hackers
[Kali](https://www.kali.org/)
[ParrotSecurity](https://www.parrotsec.org/)
[BlackArch](https://blackarch.org/)

Pour les serveurs
[CentOs](https://www.centos.org/)


5. Lancer Virtual Box et "créer une nouvelle" machine virtuelle. Les réglages par défaut suffisent mais il peut être intéressant d'allouer un peu plus de RAM et d'espace disque
pour être plus confortable.

```
    En cas de problème au lancement de la VM ("Kernel panic error"), faire WIN et rechercher les "Windows Features" ("Activer ou désactiver les fonctionnalités windows" en fr) et désactiver les options:
    -Plateforme d'ordinateur virtuel
    -Plateforme de l'hyperviseur Windows
```

6. Lancer la VM ainsi créer et lui fournir l'.iso de l'OS a installer.

7. Procéder à l'installation de l'OS. Les options par défaut sont généralement suffisante mais attention à la langue du système pour éviter de se retrouver coincer en QWERTY.

8. Pour pouvoir redimenssioner l'écran à sa guise il faut "Insérer l'image disque" d'outils complémentaires.
L'image va alors se "monter" automatiquement et devrait se lancer.
Si l'image ne se lance pas, on peut accéder directement à son contenu et lancer le script d'installation.

