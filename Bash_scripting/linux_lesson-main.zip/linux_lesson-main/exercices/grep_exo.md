1. Trouvez tous les mots finissant par "er" et leur ligne dans le fichier.



Solutions
```sh
# 1
grep -En 'er$' random_words.txt

```
