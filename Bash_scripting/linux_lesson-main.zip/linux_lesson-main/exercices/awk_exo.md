# Awk

Pour ces exercices, utilisez le fichier /data/students.csv

1. Affichez uniquement les emails des étudiants.
2. Affichez chaque étudiant au format format : "nom" "prenom".
3. Affichez chaque étudiant au format suivant: "nom" "note"/20.
4. Affichez uniquement les informations concernant Malina
5. Affichez le nombre d'étudiants.
6. Affichez la somme de toutes les notes des étudiants.
7. Affichez la moyenne de toutes les notes des étudiants (attention...).
8. Trouvez les PID de firefox (utilisez la commande 'ps -aux')


Solutions:
```sh
# 1
awk -F "|" '{print $4}' students.csv

# 2
awk -F "|" '{print $2 " " $3}' students.csv

# 3
awk -F "|" '{print $2 " " $5"/20"}' students.csv

# 4
awk -F "|" '$2 == "Malina" {print}' students.csv
# Si le champs $2 (prénom) est égal à "Malina", on affiche la ligne.

# 5
awk -F "|" 'END {print NR - 1}' students.csv

# 6
awk -F "|" '{sum += $5} END {print sum}' students.csv

# 7
awk -F "|" '{sum += $5} END {print sum/(NR - 1)}' students.csv
# sum est incrémenté à chaque ligne
# puis après le END, on affiche le résultat de sum divisé par le nombre de ligne (-1 pour ne pas compter le header)

# 8
ps -aux | grep firefox | awk '{print $2}'
# On affiche tous les processus avec un maximum d'information
# Avec grep, on ne garde que ceux relatifs à Firefox
# Avec awk, on récupère uniquement la colonne "pid" qui nous intéresse
```
