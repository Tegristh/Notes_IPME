# Cut / Tr

Pour les exercices suivant, utilisez le fichier /data/users.csv.

0. Affichez uniquement les noms de familles des utilisateurs.
0. Affichez uniquement les noms et prénoms des utilisateurs.
0. Affichez uniquement les noms et les roles des utilisateurs avec un espace entre les deux.

```sh
# 1
cut -d ';' -f 3 users.csv

# 2
cut -d ';' -f 2,3 users.csv | tr ';' ' '

# 3
cut -d ';' -f 3,7 users.csv | tr ';' ' '
# On utilise tr pour remplacer le ';' par un espace.
```
