# Racourcis claviers utiles

- Ctrl Alt T      Ouvrir un terminal
- Ctrl A          Mettre le curseur au début de la ligne
- Ctrl E          Mettre le curseur à la fin de la ligne
- Fleche Haut/Bas     Retrouve la commande précédente/suivante
- Ctrl L          "Clear" le terminal
- Tab             Auto complétion si possible
- Shift Ctrl V    Coller
- Ctrl K          Coupe tout le texte après le curseur
- Ctrl U          Coupe tout le texte avant le curseur
- Ctrl Y          Colle le texte coupé

- sudo !!         Lance la commande précédente en tant que root

