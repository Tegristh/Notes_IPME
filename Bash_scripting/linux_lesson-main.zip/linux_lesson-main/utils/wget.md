# wget

`wget` est une commande couramment utilisée sous Linux pour récupérer des fichiers depuis des serveurs Web via le protocole HTTP, HTTPS ou FTP. Voici comment utiliser `wget` :

1. Télécharger un fichier :

   ```bash
   wget URL_du_fichier
   ```

   Remplacez "URL_du_fichier" par l'URL réelle du fichier que vous souhaitez télécharger. Par exemple :

   ```bash
   wget https://www.example.com/fichier.txt
   ```

   Ce commandement téléchargera le fichier `fichier.txt` depuis l'URL spécifiée et le sauvegardera dans le répertoire courant.

2. Spécifier un nom de fichier de sortie :

   ```bash
   wget -O nom_du_fichier URL_du_fichier
   ```

   Utilisez l'option `-O` pour spécifier un nom de fichier de sortie différent de celui d'origine. Par exemple :

   ```bash
   wget -O fichier_telecharge.txt https://www.example.com/fichier.txt
   ```

   Cela téléchargera le fichier `fichier.txt` et le renommera en `fichier_telecharge.txt`.

3. Récursivement télécharger un site Web :

   ```bash
   wget -r URL_du_site_web
   ```
   Utilisez l'option `-r` pour effectuer un téléchargement récursif, ce qui signifie que `wget` téléchargera non seulement la page spécifiée, mais aussi toutes les ressources liées (images, CSS, etc.) et les pages liées. Par exemple :

   ```bash
   wget -r https://www.example.com
   ```

   Cela téléchargera tout le contenu du site Web `example.com` dans un répertoire local.

4. Limiter la bande passante :

   ```bash
   wget --limit-rate=100k URL_du_fichier
   ```

   L'option `--limit-rate` permet de limiter la vitesse de téléchargement en spécifiant la limite en kilobits par seconde (k). Par exemple :
   ```bash
   wget --limit-rate=100k https://www.example.com/fichier.txt
   ```
   Cela téléchargera le fichier `fichier.txt` en limitant la vitesse à 100 kilobits par seconde.

Ce ne sont là que quelques exemples d'utilisation de `wget`. La commande offre une variété d'options supplémentaires pour personnaliser le comportement du téléchargement, telles que l'authentification, les en-têtes personnalisés, la reprise de téléchargement, etc. Vous pouvez consulter la documentation officielle de `wget` pour en savoir plus sur ses fonctionnalités et options avancées.
