# Introduction à curl

[API d'entrainement](https://jsonplaceholder.typicode.com/)

Curl est une commande en ligne de commande qui permet d'effectuer des requêtes réseau et de transférer des données à l'aide de divers protocoles, notamment HTTP, HTTPS, FTP, SCP, etc. Curl est un outil polyvalent et largement utilisé pour récupérer des ressources à partir d'URL et interagir avec des serveurs distants.
Cette commande est donc plus puissante que wget, mais aussi plus difficile à manipuler.


## Syntaxe de base de curl
La syntaxe de base de curl est la suivante :

```bash
curl [options] [URL]
```

- `options` : représente les options utilisées pour personnaliser le comportement de curl. Certaines options couramment utilisées incluent `-X` (méthode de requête), `-H` (en-têtes HTTP), `-d` (données à envoyer), `-o` (fichier de sortie), etc.
- `URL` : spécifie l'URL à laquelle la requête sera envoyée.

Lorsque la commande curl est exécutée, elle envoie une requête à l'URL spécifiée et récupère les données correspondantes en réponse.

## Utilisation des options courantes en curl
Voici quelques options couramment utilisées avec la commande curl :

- `-X` : Spécifie la méthode de requête HTTP à utiliser. Par exemple, `-X GET` pour une requête GET, `-X POST` pour une requête POST, etc.
- `-H` : Ajoute des en-têtes HTTP personnalisés à la requête. Par exemple, `-H "Content-Type: application/json"` pour spécifier le type de contenu JSON.
- `-d` : Envoie des données dans le corps de la requête. Par exemple, `-d 'param1=valeur1&param2=valeur2'` pour envoyer des données en tant que paramètres.
- `-o` : Spécifie le fichier de sortie où les données téléchargées seront enregistrées.
- `-L` : Permet de suivre les redirections lors de l'accès à une URL.
- `-s` : Pour 'silent'. Permet de masquer l'output de la commande.

Il existe de nombreuses autres options disponibles pour personnaliser les requêtes curl en fonction de vos besoins spécifiques.

## Exemples d'utilisation de curl
Voici quelques exemples d'utilisation courante de la commande curl :

- Effectuer une requête GET vers une URL :
  ```bash
  curl URL
  ```

- Spécifier une méthode de requête :
  ```bash
  curl -X POST URL
  ```

- Ajouter des en-têtes HTTP personnalisés :
  ```bash
  curl -H "Content-Type: application/json" URL
  ```

- Envoyer des données dans le corps de la requête :
  ```bash
  curl -X POST -d 'param1=valeur1&param2=valeur2' URL
  ```

- Télécharger un fichier depuis une URL et enregistrer le résultat dans un fichier :
  ```bash
  curl -o fichier_sortie URL
  ```

- Suivre les redirections lors de l'accès à une URL :
  ```bash
  curl -L URL
  ```

- Envoyer un fichier en ftp (on utilise -u pour l'authentification) :
  ```bash
  curl -u utilisateur:motdepasse -T fichier.txt ftp://example.com/dossier/
  ```

Ces exemples vous donnent un aperçu des fonctionnalités et des options de la commande curl. Explorez davantage pour découvrir toutes les possibilités offertes par curl lors de l'interaction avec des serveurs distants et le transfert de données via différents protocoles.

