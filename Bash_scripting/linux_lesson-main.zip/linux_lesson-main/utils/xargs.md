# xargs

`xargs` est une commande Linux/Unix qui permet d'exécuter une autre commande en utilisant les arguments fournis par l'entrée standard (stdin) comme arguments de la commande à exécuter. Cela permet de traiter efficacement des listes d'arguments ou de fichiers.

Voici quelques exemples pour illustrer son utilisation :

1. Exécution d'une commande pour chaque argument :
Supposons que vous ayez une liste d'arguments, par exemple des noms de fichiers, et que vous souhaitiez exécuter une commande pour chaque argument. Vous pouvez utiliser `xargs` pour cela. Par exemple, si vous avez une liste de fichiers texte et que vous voulez afficher leur contenu, vous pouvez utiliser la commande suivante :

   ```
   cat filelist.txt | xargs cat
   ```

   Ici, `cat filelist.txt` affiche les noms de fichiers à partir du fichier `filelist.txt`, puis `xargs cat` exécute la commande `cat` pour chaque nom de fichier.

2. Spécifier le nombre d'arguments par commande :
Par défaut, `xargs` exécute la commande avec autant d'arguments que possible à chaque itération. Si vous souhaitez spécifier le nombre d'arguments à passer à chaque commande, vous pouvez utiliser l'option `-n`. Par exemple, si vous voulez exécuter la commande `echo` avec deux arguments à la fois, vous pouvez utiliser :

   ```
   echo "1 2 3 4 5" | xargs -n 2 echo
   ```

   Cela affichera deux nombres par ligne.

3. Utilisation d'un délimiteur personnalisé :
Par défaut, `xargs` utilise l'espace comme délimiteur pour les arguments. Si vos arguments contiennent des espaces ou d'autres caractères spéciaux, vous pouvez spécifier un délimiteur personnalisé en utilisant l'option `-d`. Par exemple, supposons que vous ayez une liste de fichiers avec des espaces dans leurs noms et que vous souhaitiez les supprimer tous. Vous pouvez utiliser :

   ```
   cat filelist.txt | xargs -d '\n' rm
   ```

   Ici, nous utilisons `-d '\n'` pour indiquer à `xargs` d'utiliser un retour à la ligne comme délimiteur.

