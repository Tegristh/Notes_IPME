# jq (parser json)

La commande `jq` est un outil puissant utilisé pour manipuler et filtrer les données au format JSON dans le terminal Linux. Elle permet d'extraire des données spécifiques, de les filtrer, de les transformer et de les afficher de différentes manières.

Voici quelques exemples d'utilisation courants de la commande `jq` :

1. Afficher tout le contenu d'un fichier JSON :
```bash 
jq '.' fichier.json
```

2. Extraire une clé spécifique d'un fichier JSON :
```bash
jq '.cle' fichier.json
```

3. Afficher une clé imbriquée dans une structure JSON :
```bash
jq '.cle1.cle2' fichier.json
```

4. Filtrer les données basé sur une condition :
```bash
jq 'select(.cle == "valeur")' fichier.json
```

5. Afficher les valeurs uniques d'une clé spécifique :
```bash
jq '.cle | unique' fichier.json
```

6. Compter le nombre d'éléments dans un tableau JSON :
```bash
jq '.tableau | length' fichier.json
```

7. Formater la sortie en utilisant des options de couleur :
```bash
jq -C '.' fichier.json
```

8. Récupérer toutes les valeurs de 'clé' des éléments d'un tableau :
```bash
jq '.[].cle' fichier.json
```

9. Parser le retour des données pour supprimer les guillemets :
```bash
jq -r '.cle' fichier.json
```

# Autres parsers notables

Pour manipuler des données XML, HTML et YAML dans le terminal Linux, il existe plusieurs outils similaires à `jq` qui offrent des fonctionnalités spécifiques à ces formats. Voici quelques équivalents couramment utilisés :

1. XML:
- `xmlstarlet`: C'est un outil en ligne de commande qui permet de traiter des fichiers XML. Il permet d'extraire des données, de les modifier, de les formater et bien plus encore. Voici un exemple d'utilisation pour extraire une valeur d'un fichier XML :
```bash
xmlstarlet sel -t -v "/root/element" fichier.xml
```

2. HTML:
- `pup`: C'est un outil de ligne de commande qui permet de parcourir et de manipuler des fichiers HTML en utilisant des sélecteurs CSS. Il peut extraire des données, modifier la structure HTML, etc. Voici un exemple d'utilisation pour extraire le contenu d'une balise HTML :
```bash
pup 'h1' < fichier.html | sed -n 2p
```

3. YAML:
- `yq`: C'est un outil similaire à `jq`, mais spécifiquement conçu pour manipuler des fichiers YAML. Il permet d'extraire des données, de les modifier, de les formater et bien plus encore. Voici un exemple d'utilisation pour extraire une valeur d'un fichier YAML :
```bash
yq e '.cle' fichier.yaml
```

Ces outils offrent une gamme de fonctionnalités pour travailler avec des données XML, HTML et YAML dans le terminal Linux. N'hésite pas à consulter leur documentation respective pour en savoir plus sur les différentes possibilités et options qu'ils offrent.
