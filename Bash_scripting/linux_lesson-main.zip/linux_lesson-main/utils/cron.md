# Introduction à cron
cron est un utilitaire de planification de tâches sous les systèmes d'exploitation basés sur UNIX tels que Linux. Il permet d'exécuter des commandes, des scripts ou des programmes de manière périodique et automatique, selon un horaire défini. Les tâches planifiées sont appelées "cron jobs".

## Syntaxe de base de la commande cron
La commande cron utilise un fichier appelé "crontab" (abréviation de "cron table") pour stocker les tâches planifiées. Chaque utilisateur dispose de son propre crontab.

La syntaxe de base d'une entrée de crontab est la suivante :

```
Minute    Heure    Jour du mois    Mois    Jour de la semaine    Commande
```

- `Minute` : Les minutes auxquelles la tâche doit être exécutée (0-59).
- `Heure` : L'heure à laquelle la tâche doit être exécutée (0-23).
- `Jour du mois` : Le jour du mois où la tâche doit être exécutée (1-31).
- `Mois` : Le mois où la tâche doit être exécutée (1-12).
- `Jour de la semaine` : Le jour de la semaine où la tâche doit être exécutée (0-7, 0 et 7 représentent le dimanche).
- `Commande` : La commande, le script ou le programme à exécuter.

## Utilisation de la commande cron
La commande cron offre plusieurs options pour manipuler les tâches planifiées :

- Afficher la liste des tâches planifiées :
  ```bash
  crontab -l
  ```

- Ajouter une nouvelle tâche planifiée :
  ```bash
  crontab -e
  ```

- Supprimer toutes les tâches planifiées :
  ```bash
  crontab -r
  ```

- Modifier les tâches planifiées existantes :
  ```bash
  crontab -e
  ```

- Exécuter une tâche planifiée immédiatement :
  ```bash
  crontab -l | crontab -
  ```

## Exemples d'utilisation de la commande cron
Voici quelques exemples d'utilisation courante de la commande cron :

- Exécuter un script toutes les heures :
  ```
  0 * * * * /chemin/vers/script.sh
  ```

- Exécuter une commande tous les jours à 8h00 :
  ```
  0 8 * * * commande
  ```

- Exécuter un script tous les jours à minuit :
  ```
  0 0 * * * /chemin/vers/script.sh
  ```

- Exécuter une commande toutes les semaines le dimanche à 18h00 :
  ```
  0 18 * * 0 commande
  ```

- Exécuter un script tous les mois le 1er à 12h00 :
  ```
  0 12 1 * * /chemin/vers/script.sh
  ```

Ces exemples illustrent différentes façons de définir des tâches planifiées à l'aide de la commande cron. Vous pouvez personnaliser les valeurs des minutes, des heures, des jours et

 des mois selon vos besoins.

Il est important de bien comprendre la syntaxe et de tester soigneusement vos tâches planifiées avant de les mettre en production. Assurez-vous également d'utiliser des chemins absolus pour les commandes, scripts ou programmes exécutés dans le crontab afin d'éviter des problèmes de chemin d'accès.

La commande cron est un outil puissant pour automatiser les tâches récurrentes. En l'utilisant de manière appropriée, vous pouvez gagner du temps et améliorer l'efficacité de vos opérations système.
