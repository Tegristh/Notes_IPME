1. Affichage des éléments d'un tableau : Écrire un script qui définit un tableau de noms et utilise une boucle `for` pour afficher chaque nom du tableau.

```bash
#!/bin/bash
noms=("Alice" "Bob" "Charlie" "Dave")

echo "Liste des noms :"
for nom in "${noms[@]}"; do
    echo "$nom"
done
```

2. Affichage des fichiers d'un répertoire : Écrire un script qui utilise une boucle `for` pour parcourir tous les fichiers d'un répertoire donné et les afficher.

```bash
#!/bin/bash
repertoire="/chemin/vers/repertoire"

echo "Liste des fichiers :"
for fichier in "$repertoire"/*; do
    if [ -f "$fichier" ]; then
        echo "$fichier"
    fi
done
```

3. Calcul de la somme des nombres : Écrire un script qui demande à l'utilisateur d'entrer une série de nombres, puis utilise une boucle `for` pour calculer la somme de ces nombres.

```bash
#!/bin/bash
echo "Entrez une série de nombres séparés par des espaces :"
read -a nombres

somme=0
for nombre in "${nombres[@]}"; do
    somme=$((somme + nombre))
done

echo "La somme des nombres est : $somme"
```

4. Copie de fichiers avec une extension spécifique : Écrire un script qui utilise une boucle `for` pour parcourir tous les fichiers avec une extension donnée dans un répertoire, puis les copie dans un répertoire de destination.

```bash
#!/bin/bash
repertoire_source="/chemin/source"
repertoire_destination="/chemin/destination"
extension=".txt"

echo "Copie des fichiers avec l'extension $extension vers $repertoire_destination"

for fichier in "$repertoire_source"/*"$extension"; do
    if [ -f "$fichier" ]; then
        cp "$fichier" "$repertoire_destination"
        echo "Fichier copié : $fichier"
    fi
done

echo "Copie terminée."
```

