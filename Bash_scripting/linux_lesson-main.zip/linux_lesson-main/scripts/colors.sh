#!/bin/bash

NC='\033[0m' # No Color

# Red echo for errors
echo_error() {
    local red='\033[0;31m'
    echo -e "${red}$1${NC}"
}

# Green echo for success messages
echo_success() {
    local green='\033[0;32m'
    echo -e "${green}$1${NC}"
}
