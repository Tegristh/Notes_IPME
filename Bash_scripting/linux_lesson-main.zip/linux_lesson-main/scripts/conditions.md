1. Vérification d'un nombre pair ou impair : Écrire un script qui demande un nombre à l'utilisateur, puis vérifie s'il est pair ou impair.

```bash
#!/bin/bash
echo "Entrez un nombre :"
read nombre

if (( nombre % 2 == 0 )); then
# OU if [[ $(($nombre % 2)) -eq 0 ]]
    echo "$nombre est un nombre pair."
else
    echo "$nombre est un nombre impair."
fi
```

2. Vérification de l'existence d'un fichier : Écrire un script qui demande à l'utilisateur d'entrer un chemin de fichier, puis vérifie si le fichier existe.

```bash
#!/bin/bash
echo "Entrez le chemin d'un fichier :"
read fichier

if [ -f "$fichier" ]; then
    echo "Le fichier $fichier existe."
else
    echo "Le fichier $fichier n'existe pas."
fi
```

3. Comparaison de chaînes de caractères : Écrire un script qui demande à l'utilisateur d'entrer deux chaînes de caractères, puis vérifie si elles sont identiques ou différentes.

```bash
#!/bin/bash
echo "Entrez la première chaîne de caractères :"
read chaine1

echo "Entrez la deuxième chaîne de caractères :"
read chaine2

if [ "$chaine1" == "$chaine2" ]; then
    echo "Les chaînes de caractères sont identiques."
else
    echo "Les chaînes de caractères sont différentes."
fi
```

4. Vérification de l'âge : Écrire un script qui demande à l'utilisateur d'entrer son âge, puis affiche un message en fonction de la tranche d'âge.

```bash
#!/bin/bash
echo "Entrez votre âge :"
read age

if (( age < 18 )); then
    echo "Vous êtes mineur."
elif (( age >= 18 && age <= 65 )); then
    echo "Vous êtes majeur."
else
    echo "Vous êtes senior."
fi
```

Ces exemples simples vous permettront de comprendre l'utilisation des conditions dans les scripts bash. N'hésitez pas à les modifier et à les expérimenter pour les adapter à vos besoins spécifiques.
