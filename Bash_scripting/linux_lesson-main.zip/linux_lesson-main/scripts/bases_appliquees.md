1. Salutations personnalisées : Écrire un script qui demande le nom de l'utilisateur et lui souhaite la bienvenue avec un message personnalisé.

```bash
#!/bin/bash
echo "Quel est votre nom ?"
read nom
echo "Bienvenue, $nom !"
```

2. Calculatrice simple : Écrire un script qui demande deux nombres à l'utilisateur, effectue une opération arithmétique (addition, soustraction, multiplication, division) et affiche le résultat.

```bash
#!/bin/bash
echo "Entrez le premier nombre :"
read nombre1
echo "Entrez le deuxième nombre :"
read nombre2

addition=$((nombre1 + nombre2))
soustraction=$((nombre1 - nombre2))
multiplication=$((nombre1 * nombre2))
division=$((nombre1 / nombre2))

echo "Résultats :"
echo "Addition : $addition"
echo "Soustraction : $soustraction"
echo "Multiplication : $multiplication"
echo "Division : $division"
```

3. Liste des fichiers d'un répertoire : Écrire un script qui affiche la liste des fichiers présents dans un répertoire donné.

```bash
#!/bin/bash
echo "Entrez le chemin du répertoire :"
read chemin

echo "Liste des fichiers :"
ls "$chemin"
```

4. Sauvegarde de fichiers : Écrire un script qui crée une sauvegarde des fichiers spécifiés dans un répertoire donné.

```bash
#!/bin/bash
echo "Entrez le chemin du répertoire source :"
read source

echo "Entrez le chemin du répertoire de destination pour la sauvegarde :"
read destination

# Création d'un répertoire de sauvegarde avec la date actuelle
repertoire_sauvegarde="$destination/sauvegarde_$(date +'%Y%m%d_%H%M%S')"
mkdir "$repertoire_sauvegarde"

# Copie des fichiers du répertoire source vers le répertoire de sauvegarde
cp -r "$source" "$repertoire_sauvegarde"

echo "Sauvegarde effectuée avec succès dans : $repertoire_sauvegarde"
```

Ces exemples vous donneront une introduction aux scripts bash et vous permettront de vous familiariser avec les bases du langage. N'hésitez pas à les modifier et à les expérimenter pour les adapter à vos besoins spécifiques !
