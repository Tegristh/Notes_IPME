1. Ordinateur inquiet : Écrire un script qui demande à l'utilisateur si il va bien.
Tant que l'utilisateur ne répond pas "oui", l'ordinateur doit continuer de lui demander si ça va mieux.

```bash
#!/bin/bash
while true; do
    read -p "Ca va toujours ?" reponse
    if [[ $reponse == "oui" ]]; then
        break
    fi
done

echo "Je suis rassuré !"
```

2. Compteur de nombres : Écrire un script qui demande à l'utilisateur un nombre initial, puis utilise une boucle `while` pour afficher tous les nombres de cet initial jusqu'à 0,
seconde par seconde.

```bash
#!/bin/bash
echo "Entrez un nombre initial :"
read nombre

echo "Compteur :"
while (( nombre >= 0 )); do
    echo "$nombre"
    sleep 1
    nombre=$((nombre - 1))
done
```

3. Calcul de la somme des entiers jusqu'à un nombre donné : Écrire un script qui demande à l'utilisateur un nombre, puis utilise une boucle `while` pour calculer la somme des entiers de 1 jusqu'à ce nombre.

```bash
#!/bin/bash
echo "Entrez un nombre :"
read nombre

somme=0
i=1
while (( i <= nombre )); do
    somme=$((somme + i))
    i=$((i + 1))
done

echo "La somme des entiers jusqu'à $nombre est : $somme"
```

4. Saisie continue d'un texte : Écrire un script qui demande à l'utilisateur de saisir du texte, et utilise une boucle `while` pour afficher le texte tant que l'utilisateur continue à en saisir.

```bash
#!/bin/bash
texte=""

echo "Entrez du texte (tapez 'q' pour quitter) :"
while true; do
    read saisie
    if [ "$saisie" == "q" ]; then
        break
    fi
    texte="$texte$saisie "
done

echo "Texte saisi : $texte"
```

5. Lecture d'un fichier ligne par ligne : Écrire un script qui utilise une boucle `while` pour lire un fichier ligne par ligne et l'afficher.

```bash
#!/bin/bash
fichier="chemin/vers/fichier.txt"

echo "Lecture du fichier ligne par ligne : $fichier"
while IFS= read -r ligne; do
    echo "$ligne"
done < "$fichier"
```

