# Le pipe

Le pipe (|) en Linux est un mécanisme qui vous permet de chaîner plusieurs commandes ensemble en redirigeant la sortie d'une commande vers l'entrée d'une autre. Cela facilite le traitement des données de manière séquentielle. Voici comment utiliser le pipe :

1. Syntaxe de base :

   ```
   commande1 | commande2
   ```

   La sortie de `commande1` est redirigée (pipe) vers l'entrée de `commande2`. Cela signifie que la sortie de `commande1` devient l'entrée de `commande2`.

2. Exemple d'utilisation :

   Supposons que vous souhaitiez afficher le contenu d'un fichier texte et rechercher un mot spécifique dans ce contenu. Vous pouvez utiliser les commandes `cat` et `grep` ensemble en utilisant le pipe :

   ```
   $ cat fichier.txt | grep mot
   ```

   Dans cet exemple, la commande `cat fichier.txt` affiche le contenu du fichier `fichier.txt`, et le résultat est passé en tant qu'entrée à la commande `grep` qui recherche le mot spécifié. Ainsi, vous obtenez les lignes du fichier qui contiennent le mot recherché.

3. Utilisation de multiples pipes :

   Vous pouvez également enchaîner plusieurs commandes en utilisant plusieurs pipes. Par exemple, si vous voulez afficher le contenu d'un fichier texte, filtrer les lignes qui contiennent un certain mot, puis compter le nombre de lignes correspondantes, vous pouvez utiliser les commandes `cat`, `grep` et `wc` ensemble :

   ```
   $ cat fichier.txt | grep mot | wc -l
   ```

   Dans ce cas, la sortie de `cat fichier.txt` est passée à `grep` qui filtre les lignes contenant le mot spécifié. Ensuite, la sortie de `grep` est passée à `wc -l` qui compte le nombre de lignes correspondantes.

Le pipe est un outil puissant pour traiter et manipuler les données dans le shell Linux. Il vous permet de combiner des commandes de manière flexible pour obtenir les résultats souhaités.

